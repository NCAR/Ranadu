#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
suppressMessages (suppressWarnings (
  library(Ranadu, quietly=TRUE, warn.conflicts=FALSE))
)
xp <- (0:1000)
yp <- pnorm(xp/500-1, sd=.3)

# Define UI for application that draws a histogram
ui <- fluidPage(
   
   # Application title
   titlePanel("Digitizer Resolution"),
   
   # Sidebar with a slider input for number of bins 
   sidebarLayout(
      sidebarPanel(
         sliderInput("bits",
                     "n: Number of bits = 2^n",
                     min = 1,
                     max = 8,
                     value = 4)
      ),
      
      # Show a plot of the generated distribution
      mainPanel(
         plotOutput("distBins")
      )
   )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
   
   output$distBins <- renderPlot({
      # # generate bins based on input$bins from ui.R
      # x    <- faithful[, 2] 
      # bins <- seq(min(x), max(x), length.out = input$bins + 1)
      # 
      # # draw the histogram with the specified number of bins
      # hist(x, breaks = bins, col = 'darkgray', border = 'white')

     
      plotWAC(xp, yp, xlab='Time', ylab='y', lwd=3)
      n <- input$bits
      m <- 2^n-1
      ypn <- round(yp*m)/m
      lines(xp, ypn, col='red', lwd=1.5)
      legend('topleft', legend=c('measurand', sprintf('%d-bit digitized', n)), 
             lwd=c(3,1.5), col=c('blue', 'red'))
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

