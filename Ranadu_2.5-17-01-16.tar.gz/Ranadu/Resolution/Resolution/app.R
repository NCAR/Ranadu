#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
suppressMessages (suppressWarnings (
  library(Ranadu, quietly=TRUE, warn.conflicts=FALSE))
)
xp <- (-600:600)/100
n <- 50000
X1R <- rnorm(n); X2R <- rnorm(n)
DX <- X2R - X1R
ddd <- (-600:600)/100

# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("Overlapping Measurements"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      sliderInput("separation",
                  "distance (units of sd) between measurands:",
                  min = 0,
                  max = 5,
                  value = 1,
                  step=0.1,
                  round=-1
      )
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
      plotOutput("resolutionPlot")
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  output$resolutionPlot <- renderPlot({
    # generate bins based on input$bins from ui.R
    # x    <- faithful[, 2] 
    # bins <- seq(min(x), max(x), length.out = input$bins + 1)
    # 
    # # draw the histogram with the specified number of bins
    # hist(x, breaks = bins, col = 'darkgray', border = 'white')
    D <- input$separation
    x1<-dnorm(xp+D/2); x2 <- dnorm(xp-D/2)
    y <- dnorm(xp+D/2, sd=sqrt(2))
    plotWAC(data.frame(xp, x1, x2, y), xlim=c(-5, 5), xlab=expression(paste('x [units ', sigma[x], ']')), 
            ylab='Gaussian probability distributions', legend.position='topleft')
    x2t <- x2
    x2t[(xp > -D/2-sqrt(2)) & (xp < sqrt(2)-D/2)] <- NA
    lineWAC(xp, x2t, col='darkgreen', lwd=2.5)
    text (4, 0.35, labels=sprintf('D=%.1f', D))
    text (4, 0.30, labels=sprintf('P=%.3f', 1-pnorm(-D+sqrt(2))+pnorm(-D-sqrt(2))))
    points (c(-D/2+sqrt(2), -D/2, -D/2-sqrt(2)), rep(dnorm(sqrt(2), sd=sqrt(2)), 3), pch=20, col='red')
    # points (-D/2-sqrt(2), dnorm(-sqrt(2), sd=sqrt(2)), pch=20, col='red')
    
    arrows (c(-D/2-sqrt(2), -D/2), dnorm(-sqrt(2), sd=sqrt(2)), c(-D/2, -D/2+sqrt(2)), dnorm(-sqrt(2), sd=sqrt(2)), 
            length=.2, code=3, col='red', lty=4)
    lines(c(-D/2+sqrt(2), -D/2+sqrt(2)), c(-1,1), col='red', lty=2)
    lines(c(-D/2-sqrt(2), -D/2-sqrt(2)), c(-1,1), col='red', lty=2)
    points(-D/2+sqrt(2), dnorm(sqrt(2)-D), pch=20, col='darkgreen')
    points(-D/2-sqrt(2), dnorm(-D-sqrt(2)), pch=20, col='darkgreen')
    if (D > 0) {
      arrows(-D/2, 0.04, D/2, 0.04, length=min(D/2, 0.2), code=3, col='black', lty=4)
      text(0, 0.055, labels='D')
    }

    y <- DX + D
    E <- (ecdf(y)(ddd))
    j <- which (ddd > 1.41)[1]
    P <- 1 - E[j]
    text (6, 0.75, labels=sprintf('D=%.1f', D))
    text (6, 0.70, labels=sprintf('P=%.3f', P))
    text (-0.7-D/2, 0.19, labels=expression(sqrt(2)), col='red')
    abline(v=-D/2, col='blue', lty=2)
    abline (v=D/2, col='darkgreen', lty=2)
  })
}

# Run the application 
shinyApp(ui = ui, server = server)

