### plot 1: plot specified variables vs time
RPlot1 <- function (data, spec, ...) { 
  layout(matrix(1:spec$panels, ncol = 1), widths = 1, 
         heights = c(rep(5,spec$panels-1),6))
  op <- par (mar=c(2,4,1,2)+0.1, oma=c(1.1,0,0,0))
  ylb <- expression (paste ("temperature  ATy  [", degree, "C]"))
#   g1 <- ggplotWAC (data[, c("Time", spec$panel[[1]]$var)],
#            ylab=spec$panel[[1]]$var[1], lty=c(1,1,1,2,3), lwd=c(1,1.5,1,2,1),
#            legend.position='bottomleft')+xlab(NULL)
#   g2 <- ggplotWAC (data[, c("Time", spec$panel[[2]]$var)],
#                    ylab=spec$panel[[2]]$var[1], lty=c(1,1,1,2,3), lwd=c(1,1.5,1,2,1),
#                    legend.position='bottomleft')
#   # suppressWarnings (print (g))
#   multiplot (g1,g2)
  for (panel in 1:spec$panels) {
    if (panel == spec$panels) {
      op <- par (mar=c(5,4,1,2)+0.1)
    }
    plotWAC (data[, c('Time', spec$panel[[panel]]$var)])
  }
  AddFooter ()
}
