*** shiny.js	2016-01-19 10:16:11.693936848 -0700
--- shiny.js.WAC	2016-01-28 03:04:46.036327001 -0700
***************
*** 3127,3135 ****
      el.value = value;
    },
    subscribe: function(el, callback) {
!     $(el).on('keyup.textInputBinding input.textInputBinding', function(event) {
!       callback(true);
!     });
      $(el).on('change.textInputBinding', function(event) {
        callback(false);
      });
--- 3127,3135 ----
      el.value = value;
    },
    subscribe: function(el, callback) {
!     //$(el).on('keyup.textInputBinding input.textInputBinding', function(event) {
!     //  callback(true);
!     //});
      $(el).on('change.textInputBinding', function(event) {
        callback(false);
      });
***************
*** 4949,4952 ****
  
  })();
  
! //# sourceMappingURL=shiny.js.map
\ No newline at end of file
--- 4949,4952 ----
  
  })();
  
! //# sourceMappingURL=shiny.js.map
