#' @title standardVariables
#' @description Standard set of variables, usually used in a call to getNetCDF 
#' @details Sets a standard list of variable names in VarList suitable for use in a call 
#' to getNetCDF. Optionally, add "list" to the variables.
#' The standard variables are ATX, DPXC, EWX, GGALT, LATC, LONC, MACHX, MR, PALT, 
#' PSXC, QCXC, TASX, WDC, WSC, WIC. For NCAR/RAF-produced aircraft-data files, these
#' variables are respectively the air temperature (degC), dew-point temperature (degC),
#' aircraft altitude (m), aircraft latitude (deg N), aircraft longitude (deg. E),
#' Mach Number, mixing ratio (g/kg), pressure altitude (m), ambient pressure (hPa),
#' dynamic pressure (hPa), true airspeed (m/s), wind direction (degrees relative to 
#' true north), wind speed (m/s), and vertical wind (m/s). For additional information
#' on these and other variables used in those data archives, see the document 
#' ProcessingAlgorithms.pdf with link in the github Wiki for this R package.
#' @aliases StandardVariables
#' @author William Cooper
#' @export standardVariables
#' @param list An optional list of variable names to add to the standard list
#' @examples 
#' standardVariables (c("VEW", "PLWCC"))
standardVariables <- function (list=NULL) {
  VarList <-c("ATX", "DPXC", "EWX", "GGALT", "LATC", "LONC", 
              "MACHX", "MR", "PALT", "PSXC", "QCXC", "TASX", 
              "WDC", "WSC", "WIC") 
  if (length(list) > 0) {
    VarList <- c(VarList, list)
  }  
  return (VarList)
}

#' @title getNetCDF
#' @description Loads selected variables in a specified netCDF data file into a data.frame.
#' @details 'Time' is converted to a POSIXct variable, and other variables specified in 
#' VarList are included in the data.frame. By default, the entire file is loaded, but 
#' optional arguments Start and End can limit the time range. After reading the data, the 
#' netCDF file is closed before returning the data.frame to the calling program.
#' The global attributes in the netCDF file are loaded as attributes of the returned 
#' data.frame, and attributes of each requested variable are also assigned to that column 
#' in the data.frame from the variable attributes in the netCDF file.
#' When working with attributes, it is a feature of R data.frames that subsetting loses 
#' all the assigned variable attributes. To preserve them, copy them via 
#' A <- attributes (Data$VAR), remove A$dim (e.g., A$dim <- NULL),
#' and re-assign via attributes (DataNew$VAR) <- A. The function does not handle 
#' multi-dimensional variables (e.g., CCDP, the size distribution measured by a cloud
#' droplet probe) yet; it does work for 25-Hz files, and returns with fractional-second times.
#' @aliases getnetcdf GetNetCDF
#' @author William Cooper
#' @import ncdf4
#' @importFrom signal filter sgolay
#' @importFrom stats approx
#' @export getNetCDF
#' @param fname string, full-path file name, e.g., "/scr/raf_data/PREDICT/PREDICTrf01.nc"
#' @param VarList vector of variable names to load from the netCDF file. Use "ALL" to load 
#' everything. (May produce quite large data.frames.) The default is the list given by
#' standardVariables (). 
#' SPECIAL NOTE: Some variable names
#' have a suffix indicating the location on the aircraft, like _LWI (left-wing inboard).
#' To avoid having to supply these, a partial name can be supplied, like "CONCD_", and
#' the routine will find the first matching variable and use that variable name. These
#' can always be overridden by providing the full name; this is just a convenience to
#' avoid having to look up where a particular measurement was installed in a given project.
#' @param Start An optional numeric giving the desired start time in HHMMSS format
#' @param End An optional numeric giving the desired end time in HHMMSS format
#' @param F An optional numeric entered in the data.frame as a column 'RF' all set to 
#' this integer. This may be useful when the resulting data.frame is combined with others, 
#' to have a variable distinguishing different flights.
#' @return data.frame containing the specified variables as columns, along with 'Time' 
#' and optionally the flight number 'RF'. The netCDF-file attributes and variable
#' attributes are assigned to the data.frame and columns, respectively.
#' @examples 
#' \dontrun{D <- getNetCDF ("PathToFile.nc", c("Var1", "Var2", "Var3"))}
#' \dontrun{D <- getNetCDF ("PathToFile.nc", c("Var1", "Var2"), 133000, 143000, 5)}
getNetCDF <- function (fname, VarList=standardVariables(), Start=0, End=0, F=0) {
  # This function reads the netCDF file 'fname' and extracts 
  # the variables specified in 'VarList', returning the
  # results in a data.frame. It includes the flight number F
  # in the data.frame, as variable RF. It converts "Time",
  # seconds after a reference time in the netCDF files, to
  # a POSIXct date/time variable.
  
  ## get the header information
  netCDFfile = nc_open (fname)
  if ("ALL" %in% VarList) {
    VarList <- names (netCDFfile$var)
  }
  ## check that requested variables are present in netCDF file; fail otherwise
  namesCDF <- names (netCDFfile$var)
  for (V in VarList) {
    if (is.na(V)) {next}
    if (length (which (grepl (V, namesCDF)))) {next}
    cat (sprintf ("requested variable %s not in netCDF file;\n ----> getNetCDF returning with error", V))
    return (-1)
  }
  Time <- ncvar_get (netCDFfile, "Time")
  DL <- length (Time)
  ## set the maximum data rate (but not above 100 Hz):
  Rate <- 1
  nms <- names(netCDFfile$dim)
  if ("sps25" %in% nms) {Rate <- 25}
  if ("sps50" %in% nms) {Rate <- 50}
  ## comment next line when LAMS 100-Hz vector present but no others
  if ("sps100" %in% nms) {Rate <- 100}
  # print (sprintf ("output rate for this data.frame is %d", Rate))
  # Expand Time to be high-rate if necessary
  if (Rate > 1) {
    T <- vector ("numeric", Rate*length(Time))
    for (i in 1:length(Time)) {
      for (j in 0:(Rate-1)) {
        T[(i-1)*Rate+j+1] <- Time[i] + j/Rate
      }  
    }
    Time <- T
  }
  time_units <- ncatt_get (netCDFfile, "Time", "units")
  tref <- sub ('seconds since ', '', time_units$value)
  Time <- as.POSIXct (as.POSIXct (tref, tz='UTC')+Time, tz='UTC')
  # see if limited time range wanted:
  i1 <- ifelse ((Start != 0), getIndex (Time, Start), 1)
  i2 <- ifelse ((End != 0), getIndex (Time, End) + Rate - 1, length (Time))
  # if (End != 0) {
  #   i2 <- getIndex (Time, End) + Rate - 1
  # } else {
  #   i2 <- length (Time)
  # }
  r <- i1:i2
  # r is the appropriate index for any rate, but also need
  # the 1-Hz and 5-Hz indices for interpolation:
  r1 <- ((i1-1)/Rate+1):((i2-1)/Rate+1)
  DL <- length (r1)
  Time <- Time[r]
  SE <- getStartEnd (Time)
  ## save 'Time' attributes:
  ATT <- ncatt_get (netCDFfile, "Time")   # get list of Time attributes
  for (A in names (ATT)) {
    attr(Time, A) <- ATT[[A]]
  }
  d <- data.frame(Time)
  ## save the dimensions, useful for archiving or re-writing to netCDF:-------------
  ##    but, to save space, omit the list of times
  nf <- netCDFfile
  nf$dim[1]$Time$vals <- NULL
  attr (d, "Dimensions") <- nf$dim
  ## Save all the global attributes in the netCDF file as 'd' attributes:----------
  ATT <- ncatt_get (netCDFfile, 0)   # get list of global attributes
  for (A in names (ATT)) {
    attr(d, A) <- ATT[[A]]
  }
  attr (d, "R_dataframe_created") <- date()    # add one global attribute
  
  ######------------------------------------------------------------------
  IntFilter <- function (X, inRate, outRate) {
    if (inRate == outRate) {return (X)}
    ratio <- as.integer(outRate/inRate)    ## expected to be an integer
    ## beware of missing values
    z <- zoo::na.approx (as.vector(X), maxgap=1000, na.rm = FALSE)
    z[is.na(z)] <- 0
    x <- 0:(length(X)-1)
    A <- stats::approx (x, z, n=length(X)*ratio-ratio+1)
    T <- A$y
    T <- signal::filter(signal::sgolay(4,75),T)
    ## now shift to match 25-Hz:
    n <- as.integer (ratio / 2)
    NL = length(T)
    T <- c(rep(T[1],n), T, rep(T[NL],ratio-n-1))  ## OK, even or odd ratio
    return (T)
  }
  ######------------------------------------------------------------------
  
  ## Add the requested variables:------------------------------------------------
  for (V in VarList) {
    if (is.na(V)) {next}
    ## fill in location-tag for variable name if needed:
    if (substr(V, nchar(V), nchar(V)) == '_') {
      for (ncn in namesCDF) {
        if (grepl (V, ncn)) {V <- ncn; break}   ## note, takes 1st match
      }
    }
    ## save dimensions for the variable:
    datt <- list()
    for (dd in netCDFfile$var[[V]]$dim) {
      datt[[length(datt)+1]] <- dd$name
    }    ## later, save datt as an attribute of V
    X <- ncvar_get (netCDFfile, V)
    ATT <- ncatt_get (netCDFfile, V)
    ## for Rate == 1, nothing special is needed:
    if (Rate == 1) {
      X <- X[r1]
    } else { ## other rates require flattening and possibly interpolation and filtering
      DM <- length(dim(X))           
      if (DM == 2) {    # flatten
        X <- X[,r1]
        inputRate <- dim(X)[1]
        needFilter <- ifelse ((dim(X)[1] != Rate), TRUE, FALSE)
        dim(X) <- dim(X)[1]*dim(X)[2]
        ## see if adjustment to max rate is needed
        if (needFilter) {X <- IntFilter(X, inputRate, Rate)}
      } else {  ## single-dimension (1 Hz) in high-rate file
        X <- X[r1]
        X <- IntFilter (X, 1, Rate)
      }
    } 
    ## add variable attributes as in netCDF file
    for (A in names (ATT)) {
      attr (X, A) <- ATT[[A]]
    }
    attr (X, "Dimensions") <- datt
    d[V] <- X
  }
  if (F != 0) {    # if specified, include the flight number
    RF <- rep (F, times=length(Time))    # label flight number
    d["RF"] <- RF
  }
  nc_close (netCDFfile)
  return (d)
}
