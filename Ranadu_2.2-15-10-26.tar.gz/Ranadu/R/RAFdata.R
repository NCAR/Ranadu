
#' A sample data.frame as might be constructed by getNetCDF(), 
#' containing a short period of measurements from a NSF/NCAR GV 
#' flight in a project called "IDEAS-4". The data.frame contains
#' a set of measurements, one row per second, and a "Time"
#' variable. 
#' @format The data.frame contains 301 rows and 28 variables:
#' \describe{
#'   \item{Time}{A POSIX time, units: seconds since 2013-10-01 00:00:00 +0000, time zone UTC}
#'   \item{ATTACK}{angle of attack, degrees}
#'   \item{SSLIP}{sideslip angle, degrees}
#'   \item{GGVEW}{ground speed, east component, from GPS, m/s}
#'   \item{GGVNS}{ground speed, north component, from GPS, m/s}
#'   \item{GGVSPD}{vertical speed of aircraft, from GPS, m/s}
#'   \item{VEW}{ground speed, east component, from INS, m/s}
#'   \item{VNS}{ground speed, north component, from INS, m/s}
#'   \item{ATX}{air temperature, primary measurement, deg.C}
#'   \item{DPXC}{dew point, primary measurement, deg.C}
#'   \item{THDG}{heading wrt true north, degrees}
#'   \item{ROLL}{roll angle, positive for right-wing down, degrees}
#'   \item{PITCH}{pitch angle, positive for nose up, degrees}
#'   \item{PSXC}{ambient pressure, primary measurement, hPa}
#'   \item{QCXC}{dynamic pressure, primary measurement, hPa}
#'   \item{EWX}{water vapor pressure, primary measurement, hPa}
#'   \item{RTH1}{recovery temperature, heated sensor 1, deg.C}
#'   \item{RTH2}{recovery temperature, heated sensor 2, deg.C}
#'   \item{ADIFR}{pressure difference, vertically aligned radome ports, hPa}
#'   \item{BDIFR}{pressure difference, horizontally aligned radome ports, hPa}
#'   \item{TASX}{true airspeed, primary measurement, m/s}
#'   \item{GGALT}{aircraft altitude, from GPS, m}
#'   \item{LATC}{aircraft latitude, from INS/GPS combination, deg.N}
#'   \item{LONC}{aircraft longitude, from INS/GPS combination, deg.E}
#'   \item{PLWC}{power passing through CSIRO/King LWC sensor, Watts}
#'   \item{CONCD}{droplet concentration from a CDP, per cubic cm}
#'   \item{WDC}{wind direction, GPS-corrected, degrees from north}
#'   \item{WSC}{wind speed, GPS-corrected, m/s}
#' }
#' @source \url{http://data.eol.ucar.edu/master_list/?project=IDEAS-4_GV}
"RAFdata"
