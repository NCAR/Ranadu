#' @title 
#' @description  
#' @details 
#' @aliases 
#' @author William Cooper
#' @export 
#' @param 
#' @param 
#' @return 
#' @examples 
#' \dontrun{}