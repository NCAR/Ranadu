#' @title SkewTSounding
#' @description Plots a specified segment of data from a netCDF file on a skew-T background
#' @details Superimposes a sound plot on a skew-T diagram. The sounding data can either be
#' plotted as a continuous path or averaged in intervals before plotting. The diagram
#' is generated separately via a "Skew-TDiagram" program, with the plot saved in
#' "SkewT.RData" as plot definition "g". This is used by default, but another
#' plot definition can be specified as the third parameter.
#' @aliases SkewTSounding
#' @author William Cooper
#' @export SkewTSounding
#' @param Pressure A vector of numeric values representing the pressures [hPa] where
#' temperature and dewpoint values will be provided in the next two parameters. 
#' All three vectors must be of the same length. The default is NA, in which case
#' no data will be plotted but a skew-T background will still be provided. Optionally,
#' this parameter can be a data.frame containing all three variables (pressure, 
#' temperature, dewpoint), in which case the second and third parameters can
#' be omitted. The data.frame must have variables with the exact names "Pressure",
#' "Temperature", and "DewPoint"; absence of any causes the function to return NA.
#' @param Temperature A vector of values to plot for the temperature variable [deg.C].
#' The default is NA, in which case no temperature sounding will be plotted.
#' @param DewPoint A vector of values to plot for the dew-point variable [deg.C].
#' The default is NA, in which case no dew-point sounding will be plotted.
#' @param BackgroundDefinition The Rdata-format file containing the ggplot definition for
#' the Skew-T background. Default: "~cooperw/RStudio/Ranadu/SkewT.Rdata"
#' @param AverageInterval The interval in pressuree over which to average available
#' measurements before plotting. The default value is 0, and for that value or NA
#' all values are plotted in a continuous "path".
#' @param ADD A logical variable indicating if the data for the sounding should 
#' be returned in a data.frame suitable for addition to a previously generated
#' plot specification (if TRUE) or if an entire new plot should be generated 
#' (if FALSE, the default).
#' @param pBot This and the next three parameters are normally not needed and
#' can be left at their defaults. They are provided so that the plot can be
#' tailored to special needs. pBot is the pressure at the low end of the plot,
#' normally 1000 [hPa] which is the default.
#' @param pTop The pressure at the top of the sounding [hPa]; default 100.
#' @param tBot The temperature at the low end of the abscissa axis [deg.C];
#' default -40.
#' @param tTop The temperature at the high end of the abscissa axis [deg.C];
#' default +40.
#' @param eqptFlag Selects which equivalent potential temperature to use as the
#' basis for the pseudo-adiabats. The choices are: 
#'   0: integration based on constant entropy (the default)
#'   1: the original Rossby formula
#'   2: the Bolton formula
#'   3: the Davies-Jones formula
#' @param PlotType Reserved for future implementation. The default and only available
#' option now is 0 (Skew-T). Future options may be emagram, Stuve diagram, pastagram, etc.
#' @return ggSpecs A ggplot-format definition of the full plot, with background
#' and sounding values included in the plot. Additions can be made to this 
#' specification to add components to the plot (e.g, wind barbs or a hodograph).
#' @examples 
#' \dontrun{}
SkewTSounding <- function (Pressure=NA, Temperature=NA, DewPoint=NA, 
                           BackgroundSpecs="~cooperw/RStudio/Ranadu/SkewT.Rdata",
                           AverageInterval=0, ADD=FALSE, tBot=-40, tTop=40, 
                           pBot=1000, pTop=100, eqptFlag=0, PlotType=0) {
  load ("BackgroundSpecs")
  ## A function for translation between the P-T coordinates and the skew-T plot coordinates:
  XYplot <- function (.T, .p) { 
    return (data.frame(X=(Temperature-tBot) / (tTop-tBot) - log10(Pressure/pBot) / log10(pBot/pTop), 
                       Y=log10(Pressure)))
  }
  DSKT <- data.frame()
  if (is.data.frame(Pressure) ) {
    if ("Pressure" %in% names(Pressure)) {
      if ("Temperature" %in% names(Pressure)) {
        if ("Dewpoint" %in% names(Pressure)) {
          DSKT <- Pressure
        }
      }
    } 
    if (length(DSKT) == 0) {
      print (sprintf (" SkewT call failed, required names (Pressure, Temperature, Dewpoint) not in data.frame, first argument"))
      return(NA)
    }
  } else {
    if ((length(Pressure) != length(Temperature)) || (length(Pressure) != length (Dewpoint))) {
      print (sprintf ("SkewT error, variables (P/T/DP) have different length"))
      return (NA)
    } else {
      DSKT <- data.frame (Pressure=Pressure, Temperature=Temperature, Dewpoint=Dewpoint)
    }
  }
  ## convert to plot coordinates:
  DSKT$Temperature <- XYplot (Temperature, Pressure)$X
  DSKT$Dewpoint    <- XYplot (Dewpoint   , Pressure)$X
  DSKT$Pressure    <- XYplot (Temperature, Pressure)$Y