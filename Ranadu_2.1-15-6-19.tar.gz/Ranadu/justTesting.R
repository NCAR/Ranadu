library(ncdf4)
fname <- "/Data/IDEASG/IGrf08_50.nc"
#fname <- "/Data/DEEPWAVE/DEEPWAVErf16.nc"
Data <- getNetCDF (fname, c("TASX", "GGVEW", "WIC"))
newName <- "/Data/IDEASG/IGrf08"
nc <- nc_open(fname)
B <- ncatt_get (nc, 0)
d <- data.frame()
for (A in names(B)) {
  print (sprintf ("att %s is %s", A, B[[A]]))
  attr(d, A) <- B[[A]]
}
V <- "TASX"
X <- ncvar_get (nc, V)
ATT <- ncatt_get (nc, V)
for (A in names(ATT)) {print (sprintf ("%s:%s", A, ATT[[A]]))}
nc$var[[V]]$ndims
for (dd in nc$var[[V]]$dim) {print (dd$name)}
datt <- list()
for (dd in nc$var[[V]]$dim) {
  datt[[length(datt)+1]] <- dd$name
}    ## later, save datt as an attribute of V
