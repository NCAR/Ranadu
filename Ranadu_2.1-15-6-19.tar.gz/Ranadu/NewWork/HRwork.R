library(Ranadu)
transferAttributes <- function (dsub, d) {
  ds <- dsub
  for (nm in names (ds)) {
    var <- sprintf ("d$%s", nm)
    A <- attributes (eval (parse (text=var)))
    A$dim <- NULL
    A$class <- NULL
    var2 <- sprintf ("ds$%s", nm)
    attributes (ds[,nm]) <- A
  }
  return(ds)
}

setwd("/home/Data/DEEPWAVE")
fname <- file.choose ()
Project <- "DEEPWAVE"
Flight <- "rf15"
Vars <- setVariableList (fname, standardVariables())
Data <- getNetCDF (fname, Vars)
fnew <- sprintf ("%s%s/R-%s.nc", DataDirectory (), Project, Flight)
unlink(fnew)
makeNetCDF (Data, fnew)
