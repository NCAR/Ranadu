require(tcltk)



showVariables <- function (fname) {
  netCDFfile <- open.ncdf(fname)
  vn <- names (netCDFfile$var)
  close.ncdf (netCDFfile)
  tt <- tktoplevel()
  tktitle(tt) <- ("Available Variables")
  topMenu <- tkmenu(tt)           # Create a menu
  tkconfigure(tt, menu = topMenu) # Add it to the 'tt' window
  fileMenu <- tkmenu(topMenu, tearoff = FALSE)
  tkadd(fileMenu, "command", label = "Quit", command = 
          function() tkdestroy(tt))
  tkadd(topMenu, "cascade", label = "File", menu = fileMenu)
  tkfocus(tt)  
  for (i in seq(0,length(vn),15)) {
    lbl1 <- tkbutton (tt, text=vn[i+1])
    lbl2 <- tkbutton (tt, text=vn[i+2])
    lbl3 <- tkbutton (tt, text=vn[i+3])
    lbl4 <- tkbutton (tt, text=vn[i+4])
    lbl5 <- tkbutton (tt, text=vn[i+5])
    lbl6 <- tkbutton (tt, text=vn[i+6])
    lbl7 <- tkbutton (tt, text=vn[i+7])
    lbl8 <- tkbutton (tt, text=vn[i+8])
    lbl9 <- tkbutton (tt, text=vn[i+9])
    lbl10 <-tkbutton (tt, text=vn[i+10])
    lbl11 <-tkbutton (tt, text=vn[i+11])
    lbl12 <-tkbutton (tt, text=vn[i+12])
    lbl13 <-tkbutton (tt, text=vn[i+13])
    lbl14 <-tkbutton (tt, text=vn[i+14])
    lbl15 <-tkbutton (tt, text=vn[i+15])
    tkbind(lbl1, "<1>", varClick)
    tkgrid (lbl1, lbl2, lbl3, lbl4, lbl5, lbl6, lbl7, lbl8, lbl9, lbl10, 
            lbl11, lbl12, lbl13, lbl14, lbl15)
  }
  
  tkfocus(tt)
}
varClick <- function(t) {
  print (c("Click", numeric(t)))
}
fname = "/home/Data/DEEPWAVE/DEEPWAVErf06.nc"
showVariables (fname)